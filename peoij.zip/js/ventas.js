// Vue app
var salesApp = new Vue({
  el: "#sales",
  data: {
    exchangeRate: 0,
    years: [],
    selectedYear: "",
    brands: [],
    brandSelected: "",
    models: [],
    selectedModel: "",
    selectedState: "",
    cars: [],
    mostrarPesos: true
  },
  filters: {
    thousands: function (value) {
      return parseInt(value).toLocaleString("es-UY");
    }
  }
});

//Rates
$.ajax({
  url: "https://ha.edu.uy/api/rates",
  success: function (rates) {
    $(".rate span").text(rates.uyu);
    salesApp.exchangeRate = rates.uyu;
  }
});

// Brands
$.ajax({
  url: "https://ha.edu.uy/api/brands",
  success: function (brands) {
    salesApp.brands = brands;
  }
});

//Brand
$("#brand").on("change", function () {
  $.ajax({
    url: "https://ha.edu.uy/api/models?brand=" + salesApp.brandSelected,
    success: function (models) {
      salesApp.models = models;
    }
  });
});

//Selected Brand
for (var i = 1900; i <= 2021; i++) {
  salesApp.years.push(i);
}

function obtenerAutosDeLaApi() {
  $.ajax({
    url:
      "https://ha.edu.uy/api/cars?year=" +
      salesApp.selectedYear +
      "&brand=" +
      salesApp.brandSelected +
      "&model=" +
      salesApp.selectedModel +
      "&status=" +
      salesApp.selectedState,
    success: function (resultado) {
      console.log("La API me contesto: ", resultado);
      salesApp.cars = resultado;
    }
  });
}

$("#filtrar").on("click", function () {
  obtenerAutosDeLaApi();
});

$("#btn-currency").on("click", function () {
  console.log("Click en cambiar moneda");
  salesApp.mostrarPesos = !salesApp.mostrarPesos;
  // if (salesApp.mostrarPesos === false) {
  //   salesApp.mostrarPesos = true;
  // } else {
  //   salesApp.mostrarPesos = false;
  // }
});

// LLamo por primera vez para tener autos cuando entro
obtenerAutosDeLaApi();
